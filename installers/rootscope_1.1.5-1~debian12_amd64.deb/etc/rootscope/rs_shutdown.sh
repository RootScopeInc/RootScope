#!/bin/bash

rs_mgr_pid=$(cat /tmp/rootscope/run/rs_mgr.pid)
if [ $? -ne 0 ]; then
    rs_mgr_pid=""
fi

rs_pmgr_pid=$(cat /tmp/rootscope/run/rs_pmgr.pid)
if [ $? -ne 0 ]; then
    rs_pmgr_pid=""
fi

rs_daemon_pid=$(cat /tmp/rootscope/run/rs_daemon.pid)
if [ $? -ne 0 ]; then
    rs_daemon_pid=""
fi

rs_transport_pid=$(cat /tmp/rootscope/run/rs_transport.pid)
if [ $? -ne 0 ]; then
    rs_transport_pid=""
fi

rs_daemon_ping_pid=$(cat /tmp/rootscope/run/rs_daemon_ping.pid)
if [ $? -ne 0 ]; then
    rs_daemon_ping_pid=""
fi

rs_transport_ping_pid=$(cat /tmp/rootscope/run/rs_transport_ping.pid)
if [ $? -ne 0 ]; then
    rs_transport_ping_pid=""
fi

rs_coordinator_pid=$(cat /tmp/rootscope/run/rs_coordinator.pid)
if [ $? -ne 0 ]; then
    rs_coordinator_pid=""
fi

if systemctl list-jobs | grep -q shutdown.target; then
    if [[ ! -z "$rs_mgr_pid" ]]; then
        kill -SIGUSR2 "$rs_mgr_pid"
    fi
else
    if [[ ! -z "$rs_mgr_pid" ]]; then
        kill -SIGTERM "$rs_mgr_pid"
    fi
fi

timeout=10
# Give more time for memory tracing to finish its job
if [ -f /tmp/rootscope/control/mtrace_procs ]; then
    timeout=120
fi

interval=1
elapsed=0

while [ $elapsed -lt $timeout ]; do
    if ! pgrep -x rs_mgr > /dev/null && \
       ! pgrep -x rs_pmgr > /dev/null && \
       ! pgrep -x rs_coordinator > /dev/null && \
       ! pgrep -x rs_daemon > /dev/null && \
       ! pgrep -x rs_transport > /dev/null; then
        if [[ ! -z "$rs_daemon_ping_pid" ]]; then
            kill -SIGKILL "$rs_daemon_ping_pid"
        fi
        if [[ ! -z "$rs_transport_ping_pid" ]]; then
            kill -SIGKILL "$rs_transport_ping_pid"
        fi
        exit 0
    fi
    sleep $interval
    elapsed=$((elapsed + interval))
done

# Force kill if still not dead until this point
kill -9 $(pidof rs_mgr) $(pidof rs_pmgr) $(pidof rs_daemon) $(pidof rs_transport) $(pidof rs_coordinator) $(pidof rs_daemon_ping) $(pidof rs_transport_ping)

# avoid exiting with pkill exit code
if ! pgrep -x rs_mgr > /dev/null && \
   ! pgrep -x rs_pmgr > /dev/null && \
   ! pgrep -x rs_coordinator > /dev/null && \
   ! pgrep -x rs_daemon > /dev/null && \
   ! pgrep -x rs_transport > /dev/null &&\
   ! pgrep -x rs_daemon_ping > /dev/null &&\
   ! pgrep -x rs_transport_ping > /dev/null; then
    exit 0
else 
    exit 1
fi