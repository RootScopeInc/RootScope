#!/bin/bash

function force_delete() {
    chattr -R -i "$1" > /dev/null 2>&1
    rm -rf "$1"
}

force_delete /tmp/rootscope
force_delete /opt/rootscope
force_delete /var/log/rootscope
force_delete /usr/bin/rootscope
force_delete /etc/rootscope
