#!/bin/bash

RS_MGR_CRASH_FILE="/tmp/rootscope/control/rs_pmgr_crashed"
RS_DISABLED_FILE="/etc/rootscope/control/rs_disabled"
extra_argv=()
RS_LIB_DIR=/usr/local/lib/rootscope
RS_LD_PRELOAD=""
RS_LD_LIBRARY_PATH=""

if [ -f /tmp/rootscope/control/mtrace_procs ]; then
    RS_LD_LIBRARY_PATH+=$RS_LIB_DIR/
    RS_LD_PRELOAD+="$RS_LIB_DIR/librs_malloc.so "
    RS_LD_PRELOAD+="$RS_LIB_DIR/librs_fcntl.so "

    while IFS= read -r mtrace_proc; do
        extra_argv+=("-m")
        extra_argv+=("$mtrace_proc")
    done < /tmp/rootscope/control/mtrace_procs
fi

export LD_PRELOAD=$RS_LD_PRELOAD
export LD_LIBRARY_PATH=$RS_LD_LIBRARY_PATH

if [ -f "$RS_MGR_CRASH_FILE" ]; then
    exec /usr/bin/rootscope/rs_mgr "${extra_argv[@]}" --restart --rescan 
elif [ -f "$RS_DISABLED_FILE" ]; then
    exec /usr/bin/rootscope/rs_mgr "${extra_argv[@]}" --rescan 
else
    exec /usr/bin/rootscope/rs_mgr "${extra_argv[@]}"
fi
